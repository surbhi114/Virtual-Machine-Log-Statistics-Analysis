<link href="../admin.css" rel="stylesheet" type="text/css" />

<table width="100%"  border="0" cellspacing="0" cellpadding="0">
<tr>
    <td width="17%">&nbsp;</td>
	<td width="83%"><span class="FormRow">All Rights Reserved</span></td>
</tr>
</table>
<?php // Flush the buffered output.
//mysql_close($con);
ob_end_flush();
?>
