<link href="../charts/admin.css" rel="stylesheet" type="text/css">

<table id="menu" width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="row3" id="home"><a href="main.php">HOME</a></td>
  </tr>
  <tr>
    <td class="FormRow" style="background-color:#999; " id="home"><a href="main.php"><strong style="color:white !important;">Virtual Machines</strong></a></td>
  </tr>
  
  <tr>
    <td class="row3" id="mng_denomination"><a href="performance.php?entityName='T12_VM001_Ubuntu32'">T12_VM001_Ubuntu32</a></td>
  </tr>
  <tr>
    <td class="row3" id="mng_denomination"><a href="performance.php?entityName='T12_VM002_Ubuntu32'">T12_VM002_Ubuntu32</a></td>
  </tr>
  <tr>
    <td class="row3" id="mng_denomination"><a href="performance.php?entityName='T12_VM003_Ubuntu32'">T12_VM003_Ubuntu32</a></td>
  </tr>
    <tr>
    <td class="FormRow" style="background-color:#999; " id="home"><a href="main.php"><strong style="color:white !important;">Host System</strong></a></td>
  </tr>

  <tr>
    <td class="row3" id="mng_denomination"><a href="performance.php?entityName='130.65.132.241'">130.65.132.241</a></td>
  </tr>
  <tr>
    <td class="row3" id="mng_denomination"><a href="performance.php?entityName='130.65.132.242'">130.65.132.242</a></td>
  </tr>
  <tr>
    <td class="row3" id="mng_denomination"><a href="performance.php?entityName='130.65.132.244'">130.65.132.244</a></td>
  </tr>
  <!--tr>
    <td class="row3"><a href="logout.php">Log Out</a></td>
  </tr-->
</table>
