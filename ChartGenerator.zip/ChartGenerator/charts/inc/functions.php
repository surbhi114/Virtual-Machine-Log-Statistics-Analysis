<?php 

function getCPUUsage($entityName){

}

function getCPUUsage($entityName){

}

function getCPUUsage($entityName){

}

function getCPUUsage($entityName){

}

?>