public class ConstantUtil {

	public static String LOG_STORAGE_PATH = System.getProperty("user.home")
			+ "/Desktop/logs/";
	public static String TEMPLOG_STORAGE_PATH = System.getProperty("user.home")
			+ "/Desktop/logs/";
	public static String VCENTER_URL = "https://130.65.132.240/sdk";
	public static String VCENTER_ADMIN_URL = "https://130.65.132.14/sdk";

	public static String VCENTER_USERNAME = "administrator";
	public static String VCENTER_PASSWORD = "12!@qwQW";

}
