package config;

public class Project2_Config {

	public static String getVCenterURL() { return "https://130.65.132.240/sdk" ; }
	public static String getVCenterUsername() { return "administrator" ; }
	public static String getVCenterPassword() { return "12!@qwQW" ; }
	public static long getHeartbeatThreadDelay(){return 20000;}
	public static long getSnapshotThreadDelay(){return 120000;}

}
